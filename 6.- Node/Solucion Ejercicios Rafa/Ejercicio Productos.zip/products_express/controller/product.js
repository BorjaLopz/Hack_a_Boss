const { createProduct, getAllProducts, getSingleProduct, updateSingleProduct, deleteSingleProduct } = require('../repository/product');

const createProductController = (req, res) => {
    const product = req.body;
    const productList = createProduct(product);
    res.send(productList)
}

const getAllProductsController = (req, res) => {
    res.send(getAllProducts());
}

const getSingleProductController = (req, res) => {
    const products = getSingleProduct(parseInt(req.params.id))
    res.send(products);
}
const updateSingleProductController = (req, res) => {
    const products = updateSingleProduct(parseInt(req.params.id), req.body)
    res.send(products);
}

const deleteSingleProductController = (req, res) => {
    const products = deleteSingleProduct(parseInt(req.params.id));
    res.send(products);
}

module.exports = { 
    createProductController,
    getAllProductsController, 
    getSingleProductController,
    updateSingleProductController,
    deleteSingleProductController
}