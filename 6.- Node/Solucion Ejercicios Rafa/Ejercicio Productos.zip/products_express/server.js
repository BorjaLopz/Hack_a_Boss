const express = require('express');
require('dotenv').config()
const { 
    createProductController, 
    getAllProductsController, 
    getSingleProductController,
    updateSingleProductController,
    deleteSingleProductController
} = require('./controller/product');
const bodyParser = require('body-parser')
const app = new express();
app.use(bodyParser.json())

app.post('/product', createProductController);
app.get('/product/all', getAllProductsController);
app.get('/product/single/:id', getSingleProductController);
app.put('/product/:id', updateSingleProductController);
app.delete('/product/:id', deleteSingleProductController);

app.listen(process.env.PORT, () => {
    console.log(`Server listening in port ${process.env.PORT}`)
})