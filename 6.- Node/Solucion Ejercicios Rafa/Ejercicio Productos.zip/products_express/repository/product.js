const products = [];

const createProduct = product => {
    products.push(product);
    return products;
}
const getAllProducts = () => products;

const getSingleProduct = id => products.find(product => product.id === id);

const updateSingleProduct = (id, newProduct) => {
    products.forEach(product => {
        if(product.id === id) product = newProduct;
    })
    return products;
}

const deleteSingleProduct = id => {
    const productIndex = products.findIndex(product => product.id === id);
    products.splice(productIndex, 1);
    return products;
}

module.exports = { createProduct, getAllProducts, getSingleProduct, updateSingleProduct, deleteSingleProduct }