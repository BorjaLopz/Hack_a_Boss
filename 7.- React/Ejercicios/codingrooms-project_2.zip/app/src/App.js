import './App.css';

function App() {
  return (
    <main>
      <p>Hola desde React!</p>
    </main>
  );
}

export default App;
