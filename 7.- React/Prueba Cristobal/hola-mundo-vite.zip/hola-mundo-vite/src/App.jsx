import './App.css'
import MyButton from './components/MyButton.jsx'

function App() {
  return <MyButton />
}

export default App
